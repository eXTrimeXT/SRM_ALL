package com.meicloud.mc.channel.custom;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @description:
 * @date: 2023/9/28 16:11
 */
@Slf4j
public class DahanSmsCustomChannel implements CustomChannel {
    public String channelType() {
        return "dahanSms";
    }

    public String channelTypeName() {
        return "大汉三通短信";
    }

    public List<CustomChannelParam> getChannelParams() {
        List<CustomChannelParam> params = new ArrayList<CustomChannelParam>();
        params.add(CustomChannelParam.builder()
                .label("请求地址")
                .code("address")
                .required(false).build());
        params.add(CustomChannelParam.builder()
                .label("账号")
                .code("account")
                .required(false).build());
        params.add(CustomChannelParam.builder()
                .label("密码")
                .code("password")
                .required(true).build());

        params.add(CustomChannelParam.builder()
                .label("签名")
                .code("sign")
                .required(true).build());

        return params;
    }

    public List<CustomTemplateField> getTemplateFields() {
        List<CustomTemplateField> fields = new ArrayList<CustomTemplateField>();
        fields.add(CustomTemplateField.builder()
                .fieldLabel("手机号")
                .fieldName("phones")
                .required(true)
                .build());

        fields.add(CustomTemplateField.builder()
                .fieldLabel("内容")
                .fieldName("content")
                .fieldType(FieldType.TEXT)
                .required(true)
                .build());

        return fields;
    }

    public void send(CustomChannelContext context) {

        String channelJson = context.getChannelConfigJson();
        JSONObject channelJsonObject = JSON.parseObject(channelJson);
        String address = channelJsonObject.getString("address");
        String account = channelJsonObject.getString("account");
        String password = channelJsonObject.getString("password");
        String sign = channelJsonObject.getString("sign");


        String json = context.getMessageContent();
        JSONObject templateJsonObject = JSON.parseObject(json);
        String phones = templateJsonObject.getString("phones");
        String content = templateJsonObject.getString("content");
        log.info("phones:{}", phones);

        String receiverJson = context.getReceiverJson();
        log.info("receiverJson:{}", receiverJson);

        RestTemplate restTemplate = new RestTemplate();

        String msgid = UUID.randomUUID().toString();

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json; charset=utf-8");
        JSONObject jsonParam = new JSONObject();
        jsonParam.put("account", account);
        jsonParam.put("password", password);
        jsonParam.put("sign", sign);
        jsonParam.put("msgid", msgid);
        jsonParam.put("phones", phones);
        jsonParam.put("content", content);

        HttpEntity params = new HttpEntity(jsonParam, headers);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(address, params, String.class);
        log.info("发送短信返回:{}", JSONObject.toJSON(responseEntity));
        if (HttpStatus.OK == responseEntity.getStatusCode()) {
            Map<String, String> resMap = JSON.parseObject(responseEntity.getBody(), Map.class);
            if (!"0".equals(resMap.get("result"))) {
                throw new RuntimeException(resMap.get("desc"));
            }
        } else {
            throw new RuntimeException("短信发送请求失败");
        }
    }
}
