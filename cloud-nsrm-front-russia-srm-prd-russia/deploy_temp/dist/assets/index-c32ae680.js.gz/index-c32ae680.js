import{N as NavTabs}from"./index-a035e78f.js";import{al as defineComponent,am as usePageHelper,M as getDictItem,a4 as adaptDictData,ar as defineSchemas,ae as expression,ai as generateXindexInOrder,af as i18nExpression,bt as changeFieldVisibleByDeps,as as RenderEngine,bv as systemUrl,n as normalizeComponent}from"./index-17d0ccd5.js";import{e as editEngine}from"./edit-engine-e0a8719e.js";import{v as viewInnerBoxDialog}from"./viewInnerBoxDialog-123ec703.js";const _sfc_main$2=defineComponent({__name:"goods-engine",setup(__props){const{app,emitTabAdd,t,confirmMessage,vendor:$vendor}=usePageHelper(),innerAndOutTemplate=(async()=>{let inner=await getDictItem("TAG_PRINT_TEMPLATEP_INNER"),outer=await getDictItem("TAG_PRINT_TEMPLATEP_OUTER");return{inner:adaptDictData(inner.data,"dict"),outer:adaptDictData(outer.data,"dict")}})(),viewInnerBox=(row,$form,$queryEngine)=>{$form.query(".innerBarDialog").take().setComponentProps({visible:!0}),$queryEngine.request.baseRequest({type:"TagInnerBox",action:"query",lang:"zh-cn",query:{"*":{}},payload:{filter:{outerBoxId:{eq:row.outerBoxId}}}}).then(res=>{$form.query("*.innerBarDialog.innerBarTable").take().setValue(res.data)})},unbindRequest=(payload,$queryEngine)=>{$queryEngine.request.baseRequest({type:"TagOuterBox",action:"unbound",lang:"zh-cn",query:{"*":{}},payload}).then(()=>{app.$message.success(t("common.success")),$queryEngine.state.paginationManagement.refresh()})},batchUnbind=($form,$queryEngine)=>{let selects=$form.query(".table").take().componentProps.componentInstance.getCheckboxRecords();if(selects.length<1)return app.$message.warning(t("barcodeManageNew.selectUnbindData"));if(selects.some(item=>item.boundFlag==="N"))return app.$message.warning(t("barcodeManageNew.selectBindData"));let payload=selects.map(row=>({outerBoxId:row.outerBoxId}));unbindRequest(payload,$queryEngine)},unbindBox=async(row,$queryEngine)=>{await confirmMessage(t("barcodeManageNew.sureUnbindData"))==="confirm"&&unbindRequest([{outerBoxId:row.outerBoxId}],$queryEngine)},bindBox=async row=>{emitTabAdd({component:editEngine,params:{flag:"bind",row,type:"DELIVERY_NOTE"},title:t("barcodeManageNew.bindinnerBox")+row.outerBoxCode,name:"editEngine"})},openPrint=(pdfName,params)=>{let origin=systemUrl;const xml=encodeURIComponent(pdfName),url=`${origin}/#/pdfPrint?xml=${xml}&params=${params}`;window.open(url)},printInnerBoxByOuterId=async(id,$queryEngine)=>{$queryEngine.request.baseRequest({type:"TagInnerBox",action:"query",lang:"zh-cn",query:{"*":{}},payload:{filter:{outerBoxId:{eq:id}}}}).then(res=>{let templatePathList=(res.data||[]).map(item=>item.templatePath),setTemplatePath=[...new Set(templatePathList)];setTemplatePath.length==1?printInnerOrOuterBox("inner",id,$queryEngine,setTemplatePath[0]):app.$message.warning(t("内箱存在多个模板，无法打印"))})},printInnerOrOuterBox=async(type,id,$queryEngine,templatePath)=>{let params=encodeURIComponent(`ids=${id}`);type==="inner"&&(params=encodeURIComponent(`outerBoxId=${id}`)),$vendor()?$queryEngine.request.baseRequest({type:type==="outer"?"TagOuterBox":"TagInnerBox",lang:"zh-cn",query:{"*":{}},payload:[{outerBoxId:id}],action:"print"}).then(res=>{res.data&&openPrint(templatePath,params)}):openPrint(templatePath,params)},scope={t,emitTabAdd,editEngine,viewInnerBox,unbindBox,bindBox,innerAndOutTemplate,batchUnbind,$vendor,printInnerBoxByOuterId,printInnerOrOuterBox},components={},schema=defineSchemas({TagOuterBox:{type:"void","x-query-engine":{service:"sup-ce",actions:{paginationQuery:{immediate:!0,transformRequest:expression(`(data, headers) => {
            console.log('transformRequest=>', data, headers)

            data.query['*'] = {}

            // 添加过滤条件 去除废弃
            if (!data.payload?.filter) {
              data.payload.filter = {
                status: {eq: 'Y'},
                type: { 'eq': 'DELIVERY_NOTE' },
              }
            } else {
              data.payload.filter.status = {eq: 'Y'}
              data.payload.filter.type = {eq: 'DELIVERY_NOTE'}
            }

            return data
          }`),onSuccess:expression(`async (res) => {
            console.log(res,'qqqqqq')
          }`)}}},"x-decorator":"el-container","x-component":"QueryEngine","x-decorator-props":{class:"flex-container",direction:"vertical"},properties:{innerBarDialog:{"x-decorator":"QueryEngine",...viewInnerBoxDialog},bus:{type:"void","x-component":"BusEvent","x-component-props":{eventName:"TagOuterBox","@listener":expression(`() => {
            $queryEngine.state.paginationManagement.refresh()
          }`)}},query:{type:"object","x-query-engine-skip":!0,"x-component":"QueryFormByQueryEngine",properties:generateXindexInOrder({outerBoxCode:{type:"string",title:"外箱条码","x-component":"QuickSearch","x-component-props":{showKey:"outerBoxCode",propKey:"outerBoxId",name:"scc_sc_tag_outer_box_vendor","@close-quicksearch":expression(`(val) => {
                console.log(val,'val')
                $self.value = val ? val.outerBoxCode : ''
              }`)}},materialId:{type:"string",title:i18nExpression("purchaseDemand.itemName"),"x-component":"QuickSearch","x-component-props":{showKey:"materialName",propKey:"materialId",name:"purchase_catalog_material","@close-quicksearch":expression(`(val) => {
                $self.value = val ? val.materialId : ''
              }`)}},categoryId:{type:"string",title:i18nExpression("common.categoryName"),"x-component":"QuickSearch","x-component-props":{showKey:"categoryName",propKey:"categoryId",name:"purchase_catalog_category","@close-quicksearch":expression(`(val) => {
                $self.value = val ? val.categoryId : ''
              }`)}},deliveryNumber:{type:"string",title:i18nExpression("orderMod.buyerOrderSynergy.deliveryNumber")},boundFlag:{type:"string",title:i18nExpression("orderMod.bindingState"),"x-component":"Select",enum:[{label:"已绑定",value:"Y"},{label:"未绑定",value:"N"}]}})},toolbar:{type:"void","x-component":"Space","x-component-props":{style:"margin-bottom: 16px"},properties:{bindInner:{type:"void","x-content":i18nExpression("barcodeManageNew.bindinnerBox"),"x-component":"AuthorityButton","x-component-props":{type:"primary","@click":expression(`() => {
                console.log('绑定内箱')
                emitTabAdd({
                  component: editEngine,
                  params: {
                    flag: 'add',
                    row: {},
                    type:'DELIVERY_NOTE'
                  },
                  title: '新增绑定',
                  name: 'editEngine'
                })
              }`)}},batchUnbind:{type:"void","x-content":i18nExpression("orderMod.unbind"),"x-component":"AuthorityButton","x-component-props":{type:"default","@click":expression(`() => {
                console.log('解绑')
                batchUnbind($form, $queryEngine)
                // $form.query('.table').take().componentProps.componentInstance.addRow('unshift')
              }`)}}}},table:{type:"array","x-component":"RenderTable","x-component-props":{preColumns:"seq, checkbox",openCustomTable:!0,dblclickEditable:!0,editMode:!1},properties:generateXindexInOrder({outerBoxId:{type:"string","x-hidden":!0,"x-query-engine-primary-key":!0},innerBoxId:{type:"string","x-hidden":!0,"x-query-engine-relation":"tagInnerBoxList"},lastUpdateDate:{type:"string","x-hidden":!0,"x-query-engine-sort":"desc"},outerBoxCode:{type:"string","x-query-engine-relation":"TagOuterBoxView","x-render-table-column":{title:i18nExpression("orderMod.outerBoxBarcode"),minWidth:150}},innerBoxCode:{type:"string","x-component":"Button","x-content":'{{$t("common.view")}}',"x-component-props":{type:"text","@click":expression(`() => {
                let row = $table.getRowByIndex($self.index)
                viewInnerBox(row, $form, $queryEngine)
              }`)},"x-render-table-column":{minWidth:150,title:i18nExpression("orderMod.innerBoxBarcode"),customRender:!0}},deliveryNumber:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.deliveryNumber"),minWidth:150}},deliveryLine:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.buyerOrderSynergy.deliveryLineNum"),minWidth:150}},materialName:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.materialName"),minWidth:150}},materialCode:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.buyerOrderSynergy.materialCode"),minWidth:150}},unit:{type:"string","x-render-table-column":{title:i18nExpression("purSettlementMod.unit"),minWidth:150}},vendorCode:{type:"string","x-render-table-column":{title:i18nExpression("common.vendorCode"),minWidth:150}},vendorName:{type:"string","x-render-table-column":{title:i18nExpression("common.vendorName"),minWidth:150}},relationMaterialQuantity:{type:"string","x-render-table-column":{title:"关联物料数量",minWidth:150,icon:"el-icon-question",description:"即1个外箱可装的物料数量，贴1个外箱标签"}},boundInnerBoxQuantity:{type:"string","x-render-table-column":{title:"已绑定内箱数量",minWidth:150,icon:"el-icon-question",description:"1个外箱已绑定的内箱数量"}},leftMaterialQuantity:{type:"string","x-render-table-column":{title:"待绑定内箱物料数量",minWidth:150,icon:"el-icon-question",description:"待绑定内箱物料数量：外箱关联物料数量-已绑定内箱累计关联物料数量"}},creationDate:{type:"string","x-render-table-column":{title:i18nExpression("purSettlementMod.creationDate"),minWidth:150}},createdBy:{type:"string","x-render-table-column":{title:i18nExpression("common.creator"),minWidth:150}},boundFlag:{type:"string","x-component":"Select",enum:[{label:"已绑定",value:"Y"},{label:"未绑定",value:"N"}],"x-render-table-column":{title:i18nExpression("orderMod.bindingState"),minWidth:150}},boundInnerBoxFlag:{type:"string","x-component":"DictSelect","x-component-props":{code:"YES_OR_NO"},"x-render-table-column":{title:"是否绑定内箱条码",minWidth:150}},operation:{type:"void",title:i18nExpression("common.operation"),"x-render-table-column":{minWidth:250,fixed:"right"},"x-component":"Space",properties:{unBind:{type:"void","x-component":"AuthorityButton","x-content":i18nExpression("orderMod.unbind"),"x-component-props":{type:"text","@click":expression(`() => {
                      console.log('解绑')
                      let row = $table.getRowByIndex($self.index)
                      unbindBox(row, $queryEngine)
                    }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag",".leftMaterialQuantity"],`
                    $deps[0] === 'Y'
                  `)},bind:{type:"void","x-component":"AuthorityButton","x-content":"绑定","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('绑定')
                    let row = $table.getRowByIndex($self.index)
                    bindBox(row)
                  }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag",".leftMaterialQuantity",".boundInnerBoxFlag"],`
                  $deps[2] === 'Y' && ($deps[0] === 'N' || ($deps[0] === 'Y' && $deps[1] > 0))
                  `)},printOutBar:{type:"void","x-component":"AuthorityButton","x-content":"打印外箱条码","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('打印外箱条码')
                    let row = $table.getRowByIndex($self.index)
                    printInnerOrOuterBox('outer', row.outerBoxId,$queryEngine,row.templatePath)
                  }`)}},printInnerBar:{type:"void","x-component":"AuthorityButton","x-content":"打印内箱条码","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('打印内箱条码')
                    let row = $table.getRowByIndex($self.index)
                    printInnerBoxByOuterId(row.outerBoxId,$queryEngine)
                  }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag"],`
                  $deps[0] === 'Y'
                  `)}}}})}}}});return{__sfc:!0,app,emitTabAdd,t,confirmMessage,$vendor,innerAndOutTemplate,viewInnerBox,unbindRequest,batchUnbind,unbindBox,bindBox,openPrint,printInnerBoxByOuterId,printInnerOrOuterBox,scope,components,schema,RenderEngine}}});var _sfc_render$2=function(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c(_setup.RenderEngine,{attrs:{pageAttrs:_vm.$attrs,schema:_setup.schema,components:_setup.components,scope:_setup.scope,schemaKey:"TagOuterBox"}})},_sfc_staticRenderFns$2=[],__component__$2=normalizeComponent(_sfc_main$2,_sfc_render$2,_sfc_staticRenderFns$2,!1,null,null,null,null);const goodsEngine=__component__$2.exports,_sfc_main$1=defineComponent({__name:"matter-engine",setup(__props){const{app,emitTabAdd,t,http,confirmMessage,vendor:$vendor}=usePageHelper(),innerAndOutTemplate=(async()=>{let inner=await getDictItem("TAG_PRINT_TEMPLATEP_INNER"),outer=await getDictItem("TAG_PRINT_TEMPLATEP_OUTER");return{inner:adaptDictData(inner.data,"dict"),outer:adaptDictData(outer.data,"dict")}})(),viewInnerBox=(row,$form,$queryEngine)=>{$form.query(".innerBarDialog").take().setComponentProps({visible:!0}),$queryEngine.request.baseRequest({type:"TagInnerBox",action:"query",lang:"zh-cn",query:{"*":{}},payload:{filter:{outerBoxId:{eq:row.outerBoxId}}}}).then(res=>{$form.query("*.innerBarDialog.innerBarTable").take().setValue(res.data)})},unbindRequest=(payload,$queryEngine)=>{$queryEngine.request.baseRequest({type:"TagOuterBox",action:"unbound",lang:"zh-cn",query:{"*":{}},payload}).then(()=>{app.$message.success(t("common.success")),$queryEngine.state.paginationManagement.refresh()})},batchUnbind=($form,$queryEngine)=>{let selects=$form.query(".table").take().componentProps.componentInstance.getCheckboxRecords();if(selects.length<1)return app.$message.warning(t("barcodeManageNew.selectUnbindData"));if(selects.some(item=>item.boundFlag==="N"))return app.$message.warning(t("barcodeManageNew.selectBindData"));let payload=selects.map(row=>({outerBoxId:row.outerBoxId}));unbindRequest(payload,$queryEngine)},unbindBox=async(row,$queryEngine)=>{await confirmMessage(t("barcodeManageNew.sureUnbindData"))==="confirm"&&unbindRequest([{outerBoxId:row.outerBoxId}],$queryEngine)},bindBox=async row=>{emitTabAdd({component:editEngine,params:{flag:"bind",row,type:"MATERIAL"},title:t("barcodeManageNew.bindinnerBox")+row.outerBoxCode,name:"editEngine"})},openPrint=(pdfName,params)=>{const xml=encodeURIComponent(pdfName),url=`${systemUrl}/#/pdfPrint?xml=${xml}&params=${params}`;window.open(url)},printInnerBoxByOuterId=async(id,$queryEngine)=>{$queryEngine.request.baseRequest({type:"TagInnerBox",action:"query",lang:"zh-cn",query:{"*":{}},payload:{filter:{outerBoxId:{eq:id}}}}).then(res=>{let templatePathList=(res.data||[]).map(item=>item.templatePath),setTemplatePath=[...new Set(templatePathList)];setTemplatePath.length==1?printInnerOrOuterBox("inner",id,$queryEngine,setTemplatePath[0]):app.$message.warning(t("内箱存在多个模板，无法打印"))})},printInnerOrOuterBox=async(type,id,$queryEngine,templatePath)=>{let params=encodeURIComponent(`ids=${id}`);type==="inner"&&(params=encodeURIComponent(`outerBoxId=${id}`)),$vendor()?$queryEngine.request.baseRequest({type:type==="outer"?"TagOuterBox":"TagInnerBox",lang:"zh-cn",query:{"*":{}},payload:[{outerBoxId:id}],action:"print"}).then(res=>{res.data&&openPrint(templatePath,params)}):openPrint(templatePath,params)},scope={t,emitTabAdd,editEngine,viewInnerBox,unbindBox,bindBox,printInnerOrOuterBox,printInnerBoxByOuterId,innerAndOutTemplate,batchUnbind},components={},schema=defineSchemas({TagOuterBox:{type:"void","x-query-engine":{service:"sup-ce",actions:{paginationQuery:{immediate:!0,transformRequest:expression(`(data, headers) => {
            console.log('transformRequest=>', data, headers)

            data.query = {
              '*': {}
            }

            // 添加过滤条件 去除废弃
            if (!data.payload?.filter) {
              data.payload.filter = {
                status: {eq: 'Y'},
                type: { 'eq': 'MATERIAL' }
              }
            } else {
              data.payload.filter.status = {eq: 'Y'}
              data.payload.filter.type = {eq: 'MATERIAL'}
            }

            return data
          }`)}}},"x-decorator":"QueryEngine","x-component":"el-container","x-component-props":{class:"flex-container",direction:"vertical"},properties:{innerBarDialog:{"x-decorator":"QueryEngine",...viewInnerBoxDialog},bus:{type:"void","x-component":"BusEvent","x-component-props":{eventName:"TagOuterBox","@listener":expression(`() => {
            $queryEngine.state.paginationManagement.refresh()
          }`)}},query:{type:"object","x-query-engine-skip":!0,"x-component":"QueryFormByQueryEngine",properties:generateXindexInOrder({materialId:{type:"string",title:i18nExpression("purchaseDemand.itemName"),"x-component":"QuickSearch","x-component-props":{showKey:"materialName",propKey:"materialId",name:"purchase_catalog_material","@close-quicksearch":expression(`(val) => {
                $self.value = val ? val.materialId : ''
              }`)}},categoryId:{type:"string",title:i18nExpression("common.categoryName"),"x-component":"QuickSearch","x-component-props":{showKey:"categoryName",propKey:"categoryId",name:"purchase_catalog_category","@close-quicksearch":expression(`(val) => {
                $self.value = val ? val.categoryId : ''
              }`)}},barcodeRule:{type:"string",title:"条码规则","x-component":"DictSelect","x-component-props":{code:""}},boundFlag:{type:"string",title:i18nExpression("orderMod.bindingState"),"x-component":"Select",enum:[{label:"已绑定",value:"Y"},{label:"未绑定",value:"N"}]}})},toolbar:{type:"void","x-component":"Space","x-component-props":{style:"margin-bottom: 16px"},properties:{bindInner:{type:"void","x-content":i18nExpression("barcodeManageNew.bindinnerBox"),"x-component":"AuthorityButton","x-component-props":{type:"primary","@click":expression(`() => {
                console.log('绑定内箱')

                emitTabAdd({
                  component: editEngine,
                  params: {
                    flag: 'add',
                    row: {},
                    type:'MATERIAL'
                  },
                  title: '新增绑定',
                  name: 'editEngine'
                })
              }`)}},batchUnbind:{type:"void","x-content":i18nExpression("orderMod.unbind"),"x-component":"AuthorityButton","x-component-props":{type:"default","@click":expression(`() => {
                console.log('解绑')
                batchUnbind($form, $queryEngine)
                $form.query('.table').take().componentProps.componentInstance.addRow('unshift')
              }`)}}}},table:{type:"array","x-component":"RenderTable","x-component-props":{preColumns:"seq, checkbox",openCustomTable:!0,dblclickEditable:!0,editMode:!1},properties:generateXindexInOrder({lastUpdateDate:{type:"string","x-hidden":!0,"x-query-engine-sort":"desc"},outerBoxCode:{type:"string","x-query-engine-relation":"TagOuterBoxView","x-render-table-column":{title:i18nExpression("orderMod.outerBoxBarcode"),minWidth:150}},innerBoxCode:{type:"string","x-component":"Button","x-content":'{{$t("common.view")}}',"x-component-props":{type:"text","@click":expression(`() => {
                let row = $table.getRowByIndex($self.index)
                viewInnerBox(row, $form, $queryEngine)
              }`)},"x-render-table-column":{minWidth:150,title:i18nExpression("orderMod.innerBoxBarcode"),customRender:!0}},materialName:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.materialName"),minWidth:150}},materialCode:{type:"string","x-render-table-column":{title:i18nExpression("orderMod.buyerOrderSynergy.materialCode"),minWidth:150}},categoryName:{type:"string","x-render-table-column":{title:"品类名称",minWidth:150}},categoryCode:{type:"string","x-render-table-column":{title:"品类编码",minWidth:150}},unit:{type:"string","x-render-table-column":{title:i18nExpression("purSettlementMod.unit"),minWidth:150}},vendorCode:{type:"string","x-render-table-column":{title:i18nExpression("common.vendorCode"),minWidth:150}},vendorName:{type:"string","x-render-table-column":{title:i18nExpression("common.vendorName"),minWidth:150}},relationMaterialQuantity:{type:"string","x-render-table-column":{title:"关联物料数量",minWidth:150,icon:"el-icon-question",description:"即1个外箱可装的物料数量，贴1个外箱标签"}},boundinnerboxquantity:{type:"string","x-render-table-column":{title:"已绑定内箱数量",minWidth:150,icon:"el-icon-question",description:"1个外箱已绑定的内箱数量"}},leftmaterialquantity:{type:"string","x-render-table-column":{title:"待绑定内箱物料数量",minWidth:150,icon:"el-icon-question",description:"关联物料数量-已绑定内箱数量*内箱关联物料数量"}},boundFlag:{type:"string","x-component":"Select",enum:[{label:"已绑定",value:"Y"},{label:"未绑定",value:"N"}],"x-render-table-column":{title:"绑定状态",minWidth:150}},creationDate:{type:"string","x-render-table-column":{title:i18nExpression("purSettlementMod.creationDate"),minWidth:150}},createdBy:{type:"string","x-render-table-column":{title:i18nExpression("common.creator"),minWidth:150}},operation:{type:"void",title:i18nExpression("common.operation"),"x-render-table-column":{minWidth:210,fixed:"right"},"x-component":"Space",properties:{unBind:{type:"void","x-component":"AuthorityButton","x-content":i18nExpression("orderMod.unbind"),"x-component-props":{type:"text","@click":expression(`() => {
                      console.log('解绑')
                      let row = $table.getRowByIndex($self.index)
                      unbindBox(row, $queryEngine)
                    }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag"],`
                    $deps[0] === 'Y'
                  `)},bind:{type:"void","x-component":"AuthorityButton","x-content":"绑定","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('绑定')
                    let row = $table.getRowByIndex($self.index)
                    bindBox(row)
                  }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag"],`
                  $deps[0] === 'N'
                  `)},printOutBar:{type:"void","x-component":"AuthorityButton","x-content":"打印外箱条码","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('打印外箱条码')
                    let row = $table.getRowByIndex($self.index)
                    printInnerOrOuterBox('outer', row.outerBoxId,$queryEngine,row.templatePath)
                  }`)}},printInnerBar:{type:"void","x-component":"AuthorityButton","x-content":"打印内箱条码","x-component-props":{type:"text","@click":expression(`() => {
                    console.log('打印内箱条码')
                    let row = $table.getRowByIndex($self.index)
                    printInnerBoxByOuterId(row.outerBoxId,$queryEngine)
                  }`)},"x-reactions":changeFieldVisibleByDeps([".boundFlag"],`
                  $deps[0] === 'Y'
                  `)}}}})}}}});return{__sfc:!0,app,emitTabAdd,t,http,confirmMessage,$vendor,innerAndOutTemplate,viewInnerBox,unbindRequest,batchUnbind,unbindBox,bindBox,openPrint,printInnerBoxByOuterId,printInnerOrOuterBox,scope,components,schema,RenderEngine}}});var _sfc_render$1=function(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c(_setup.RenderEngine,{attrs:{pageAttrs:_vm.$attrs,schema:_setup.schema,components:_setup.components,scope:_setup.scope,schemaKey:"TagOuterBox"}})},_sfc_staticRenderFns$1=[],__component__$1=normalizeComponent(_sfc_main$1,_sfc_render$1,_sfc_staticRenderFns$1,!1,null,null,null,null);const matterEngine=__component__$1.exports,_sfc_main={name:"BarcodeRelation",components:{NavTabs},data(){return{historyTabName:"goodsEngine",activeTab:"goodsEngine",tabs:[{title:"按送货单",name:"goodsEngine",component:goodsEngine,closable:!1},{title:"按物料",name:"matterEngine",component:matterEngine,closable:!1}]}},watch:{activeTab(_newVal,oldVal){["goodsEngine","matterEngine"].includes(oldVal)&&(this.historyTabName=oldVal)}},methods:{tabChange(tab){this.activeTab=tab,this.tabs=this.$refs.tabs.tabs},tabRemove({activeTab}){["goodsEngine","matterEngine"].includes(activeTab)&&(this.$refs.tabs.activeTab=this.historyTabName)}}};var _sfc_render=function(){var _vm=this,_c=_vm._self._c;return _c("NavTabs",{ref:"tabs",attrs:{"tabs-list":_vm.tabs,"cur-tab":_vm.activeTab},on:{"tab-change":_vm.tabChange,"tab-remove":_vm.tabRemove}})},_sfc_staticRenderFns=[],__component__=normalizeComponent(_sfc_main,_sfc_render,_sfc_staticRenderFns,!1,null,null,null,null);const index=__component__.exports;export{index as default};
